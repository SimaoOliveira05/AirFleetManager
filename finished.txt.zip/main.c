#include "aeronaves.h"
#include "voos.h"
#include "estatisticas.h"



void menu() {

//Menu para facilitar a utilização do programa
    printf("Menu:\n");
    printf("1. Importar dados de aeronaves\n");
    printf("2. Importar dados de voos\n");
    printf("3. Listar todas as aeronaves\n");
    printf("4. Listar todas as aeronaves de uma esquadra\n");
    printf("5. Listar todos os voos\n");
    printf("6. Listar todos os voos de uma aeronave\n");
    printf("7. Listar todos os voos entre duas datas\n");
    printf("8. Mostrar estatísticas\n");
    printf("0. Sair\n");
}

int main() {
    int opcao, esquadra, nCauda;
    char resposta[4];
    char filename[100];
    char data_maior[11],data_menor[11];

    while (1) {
        menu();
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);
        printf("\n\n");
        switch (opcao) {
            case 1:
                printf("Digite o nome do ficheiro de aeronaves: ");
                scanf("%s", filename);
                importar_aeronaves(filename);
                break;
            case 2:
                printf("Digite o nome do ficheiro de voos: ");
                scanf("%s", filename);
                importar_voos(filename);
                break;
            case 3:
                if (total_aeronaves == 0)
                    printf("O nosso sistema não possui qualquer aeronave registada.\n\n\n");
                else{
                    listaTodasAeronaves();
                    printf("Deseja exportar esta lista para um ficheiro?(S/N):");
                    scanf("%s",resposta);
                    if (strcmp(resposta,"S") == 0){
                        printf("\nIntroduza o nome do ficheiro para o qual deseja exportar: ");
                        scanf("%s",filename);
                        exportar_todas_aeronaves(filename);
                    }
                    else 
                        printf("\n\n\n");
                }
                break;
            case 4:
                printf("Digite o número da esquadra: ");
                scanf("%d", &esquadra);
                listaAeronavesEsquadra(esquadra);
                printf("Deseja exportar esta lista para um ficheiro?(S/N):");
                    scanf("%s",resposta);
                    if (strcmp(resposta,"S") == 0){
                        printf("\nIntroduza o nome do ficheiro para o qual deseja exportar: ");
                        scanf("%s",filename);
                        exportar_aeronaves_esquadra(filename,esquadra);
                    }
                    else 
                        printf("\n\n\n");
                break;
            case 5:
                if (total_voos == 0)
                    printf("O nosso sistema não possui qualquer voo registado.\n\n\n");
                else{
                    listaTodosVoos();
                    printf("Deseja exportar esta lista para um ficheiro?(S/N):");
                    scanf("%s",resposta);
                    if (strcmp(resposta,"S") == 0){
                        printf("\nIntroduza o nome do ficheiro para o qual deseja exportar: ");
                        scanf("%s",filename);
                        exportar_todos_voos(filename);
                    }
                    else 
                        printf("\n\n\n");
                }
                break;
            case 6:
                printf("Digite o número de cauda da aeronave: ");
                scanf("%d", &nCauda);
                listaVoosCauda(nCauda);
                printf("Deseja exportar esta lista para um ficheiro?(S/N):");
                    scanf("%s",resposta);
                    if (strcmp(resposta,"S") == 0){
                        printf("\nIntroduza o nome do ficheiro para o qual deseja exportar: ");
                        scanf("%s",filename);
                        exportar_listaVoosCauda(filename,nCauda);
                    }
                    else 
                        printf("\n\n\n");
                break;
            case 7:
                printf("Digite entre quais datas pretende procurar: ");
                scanf("%s %s",data_menor,data_maior);
                printf("\n\n\n");
                listaVoosData(data_menor,data_maior);
                printf("Deseja exportar esta lista para um ficheiro?(S/N):");
                    scanf("%s",resposta);
                    if (strcmp(resposta,"S") == 0){
                        printf("\nIntroduza o nome do ficheiro para o qual deseja exportar: ");
                        scanf("%s",filename);
                        exportar_listaVoosData(data_menor,data_maior,filename);
                    }
                    else 
                        printf("\n\n\n");
                break;
            case 8:
                maioresHoras();
                maisHoras();
                break;
            case 0:
                return 0;
        }
    }
    return 0;
}